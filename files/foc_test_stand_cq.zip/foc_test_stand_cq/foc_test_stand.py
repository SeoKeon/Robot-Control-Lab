"""
2804 짐벌모터 + AS5600(TENSTAR 22.5x22.9) + B-G431B-ESC1 테스트 거치대
CadQuery 파라메트릭 모델

사용법 (VS Code):
  1) OCP CAD Viewer 패널을 연 상태에서 이 파일을 실행 -> 조립 상태가 뷰어에 표시됨
  2) 실행하면 같은 폴더의 out/ 에 부품별 STEP / STL 이 생성됨
     STEP -> FreeCAD 편집용,  STL(or STEP) -> Bambu Studio 출력용
단위: mm
"""
from pathlib import Path
import cadquery as cq

# =====================================================================
# 파라미터
# =====================================================================
# --- 모터 (2804) ---
MOTOR_D = 35.0
SLOT_R_MIN = 6.0        # 방사형 슬롯: 4홀 피치 12mm ~ 25mm 대응
SLOT_R_MAX = 12.5
SLOT_W = 3.3            # M3 (M2.5면 2.8)
CENTER_HOLE_D = 12.0

# --- 중공축 / 자석 ---
SHAFT_IDS = [5.4, 6.0, 6.5]   # 3종 출력 후 꽉 끼는 것 사용
MAGNET_D = 6.0                # 직경방향 착자 6x2.5
MAGNET_H = 2.5

# --- AS5600 브레이크아웃 (TENSTAR, 판매 페이지 치수) ---
SENSOR_W = 22.5               # 가로 (핀 헤더 방향)
SENSOR_L = 22.9               # 세로
SENSOR_HOLE_PITCH = 16.2      # 모서리 구멍 간격 (사진 기준 추정값 -> 실측 권장)
SENSOR_SCREW_PILOT = 1.7      # M2 셀프태핑 (보드 구멍이 커서 피치 오차 흡수)
HEADER_ROW_Y = 6.5            # 보드 중심 ~ 헤더 줄 거리 (4핀: DIR/SCL/SDA/GPO, 3핀: VCC/OUT/GND)
SENSOR_POCKET = 1.0

# --- B-G431B-ESC1 (ST 공식: ST-LINK 포함 30 x 41 mm) ---
ESC_L = 41.0
ESC_W = 30.0
ESC_CLEAR = 1.0               # 트레이 여유

# --- 구조 ---
BASE_T = 4.0
TOWER = 46.0
WALL = 3.0
TOWER_H = 26.0
PLATE_T = 4.0
CORNER_PILOT = 2.8            # M3 셀프태핑
POST_X = 15.0
POST_D = 7.0
CARRIER_T = 4.0
CARRIER_W = 28.0
CARRIER_GAP = 9.0             # 기본 상태 캐리어 윗면 ~ 모터판 아랫면 (스페이서로 줄임)
SPACERS = [0.6, 1.0, 2.0, 3.0, 4.0]
TOL = 0.2

# --- 파생값 ---
HALF = TOWER / 2
INNER = TOWER - 2 * WALL
CORNER_XY = HALF - WALL - 2
POST_H = TOWER_H - CARRIER_GAP - CARRIER_T
TRAY_IL = ESC_L + 2 * ESC_CLEAR
TRAY_IW = ESC_W + 2 * ESC_CLEAR
TRAY_X = HALF + 6 + TRAY_IL / 2 + 2
BASE_X0 = -HALF - 6
BASE_X1 = TRAY_X + TRAY_IL / 2 + 2 + 7
BASE_Y = max(TOWER, TRAY_IW + 4) / 2 + 6
CARRIER_L = 2 * POST_X + POST_D + 2


def rbox(x, y, h, r=3.0):
    """모서리가 둥근 직육면체 (바닥이 z=0)"""
    return cq.Workplane("XY").rect(x, y).extrude(h).edges("|Z").fillet(r)


# =====================================================================
# 1) 베이스 + 타워 + ESC 트레이
# =====================================================================
def make_base():
    base = rbox(BASE_X1 - BASE_X0, 2 * BASE_Y, BASE_T, 5).translate(
        ((BASE_X0 + BASE_X1) / 2, 0, 0))
    base = base.edges(">Z").fillet(1.0)

    tower = (rbox(TOWER, TOWER, TOWER_H, 3)
             .cut(cq.Workplane("XY").rect(INNER, INNER).extrude(TOWER_H))
             .translate((0, 0, BASE_T)))
    corners = (cq.Workplane("XY", origin=(0, 0, BASE_T))
               .pushPoints([(sx * CORNER_XY, sy * CORNER_XY)
                            for sx in (-1, 1) for sy in (-1, 1)])
               .rect(6, 6).extrude(TOWER_H))
    posts = (cq.Workplane("XY", origin=(0, 0, BASE_T))
             .pushPoints([(-POST_X, 0), (POST_X, 0)])
             .circle(POST_D / 2).extrude(POST_H))
    tray_walls = (cq.Workplane("XY", origin=(0, 0, BASE_T))
                  .pushPoints([(TRAY_X, sy * (TRAY_IW / 2 + 1)) for sy in (-1, 1)])
                  .rect(TRAY_IL, 2).extrude(6))
    rails = (cq.Workplane("XY", origin=(0, 0, BASE_T))
             .pushPoints([(TRAY_X, sy * (TRAY_IW / 2 - 3)) for sy in (-1, 1)])
             .rect(TRAY_IL - 6, 2.5).extrude(2))

    body = base.union(tower).union(corners).union(posts).union(tray_walls).union(rails)

    # --- 구멍/창 ---
    cuts = (cq.Workplane("XY", origin=(0, 0, BASE_T + TOWER_H - 12))
            .pushPoints([(sx * CORNER_XY, sy * CORNER_XY)
                         for sx in (-1, 1) for sy in (-1, 1)])
            .circle(CORNER_PILOT / 2).extrude(13))
    cuts = cuts.union(cq.Workplane("XY", origin=(0, 0, BASE_T + POST_H - 10))
                      .pushPoints([(-POST_X, 0), (POST_X, 0)])
                      .circle(CORNER_PILOT / 2).extrude(11))
    win_h = TOWER_H - 8
    zc = BASE_T + TOWER_H / 2 + 1
    for pos, size in [((0, -HALF, zc), (INNER - 14, WALL * 3, win_h)),   # 앞 작업창
                      ((0, HALF, zc), (INNER - 14, WALL * 3, win_h)),    # 뒤 작업창
                      ((HALF, 0, zc), (WALL * 3, INNER - 16, win_h))]:   # ESC쪽 케이블창
        cuts = cuts.union(cq.Workplane("XY").box(*size).translate(pos))
    # 케이블타이 슬롯
    zip_pts = [(TRAY_X + dx, sy * (TRAY_IW / 2 + 5))
               for dx in (-TRAY_IL / 2 + 8, TRAY_IL / 2 - 8) for sy in (-1, 1)]
    cuts = cuts.union(cq.Workplane("XY").pushPoints(zip_pts).rect(4, 2.2).extrude(BASE_T))
    # 책상 고정 구멍
    desk = [(x, sy * (BASE_Y - 5)) for x in (BASE_X0 + 5, BASE_X1 - 5) for sy in (-1, 1)]
    cuts = cuts.union(cq.Workplane("XY").pushPoints(desk).circle(2).extrude(BASE_T))
    # 타워 바닥 배선 구멍
    cuts = cuts.union(cq.Workplane("XY").center(0, -8).circle(5).extrude(BASE_T))
    return body.cut(cuts)


# =====================================================================
# 2) 모터판
# =====================================================================
def make_motor_plate():
    p = rbox(TOWER, TOWER, PLATE_T, 3)
    p = p.faces(">Z").workplane().hole(CENTER_HOLE_D)
    slot_len = SLOT_R_MAX - SLOT_R_MIN + SLOT_W
    slot_c = (SLOT_R_MIN + SLOT_R_MAX) / 2
    pts = [(slot_c, 0), (0, slot_c), (-slot_c, 0), (0, -slot_c)]
    angs = [0, 90, 0, 90]
    for (x, y), a in zip(pts, angs):
        p = p.cut(cq.Workplane("XY").center(x, y).slot2D(slot_len, SLOT_W, a).extrude(PLATE_T))
        # 아래쪽 나사머리 자리 (모터를 판에 아래서 체결)
        p = p.cut(cq.Workplane("XY").center(x, y)
                  .slot2D(slot_len + 2.7, 6.0, a).extrude(1.5))
    p = (p.faces(">Z").workplane()
         .pushPoints([(sx * CORNER_XY, sy * CORNER_XY) for sx in (-1, 1) for sy in (-1, 1)])
         .cboreHole(3.4, 6.2, 1.8))
    # 0° 기준 삼각 표시
    mark = (cq.Workplane("XY", origin=(0, 0, PLATE_T - 0.6))
            .polyline([(-2, HALF - 4), (2, HALF - 4), (0, HALF - 1)]).close().extrude(1))
    return p.cut(mark)


# =====================================================================
# 3) 센서 캐리어 (AS5600 칩 면이 위 = 자석 쪽, 헤더 핀은 아래로)
# =====================================================================
def make_sensor_carrier():
    c = rbox(CARRIER_L, CARRIER_W, CARRIER_T, 2)
    pocket = (cq.Workplane("XY", origin=(0, 0, CARRIER_T - SENSOR_POCKET))
              .rect(SENSOR_W + 2 * TOL, SENSOR_L + 2 * TOL).extrude(SENSOR_POCKET))
    headers = (cq.Workplane("XY")
               .pushPoints([(0, HEADER_ROW_Y), (0, -HEADER_ROW_Y)])
               .rect(12.5, 3.4).extrude(CARRIER_T))
    relief = cq.Workplane("XY").circle(4).extrude(CARRIER_T)
    post_holes = (cq.Workplane("XY").pushPoints([(-POST_X, 0), (POST_X, 0)])
                  .circle(1.7).extrude(CARRIER_T))
    h = SENSOR_HOLE_PITCH / 2
    screw = (cq.Workplane("XY").pushPoints([(h, h), (-h, -h)])   # 대각 2개면 충분
             .circle(SENSOR_SCREW_PILOT / 2).extrude(CARRIER_T))
    return c.cut(pocket).cut(headers).cut(relief).cut(post_holes).cut(screw)


# =====================================================================
# 4) 스페이서 세트 (기둥 2개 x 5종)
# =====================================================================
def make_spacers():
    out = cq.Workplane("XY")
    for i, t in enumerate(SPACERS):
        for j in (0, 1):
            ring = (cq.Workplane("XY").circle(4).circle(1.75).extrude(t)
                    .translate((i * 11, j * 11, 0)))
            out = out.union(ring)
    return out


# =====================================================================
# 5) 자석 플러그 (중공축 아래쪽에 압입, 자석은 아래 = 센서 쪽)
# =====================================================================
def make_magnet_plug(shaft_id):
    head_h = MAGNET_H + 1.2
    stem_l = 5.0
    head = cq.Workplane("XY").circle(5).extrude(head_h)
    stem = cq.Workplane("XY").add(
        cq.Solid.makeCone((shaft_id + 0.05) / 2, (shaft_id - 0.25) / 2, stem_l,
                          pnt=cq.Vector(0, 0, head_h)))
    plug = head.union(stem)
    plug = plug.cut(cq.Workplane("XY").circle((MAGNET_D + TOL) / 2).extrude(MAGNET_H))
    slit = (cq.Workplane("XY", origin=(0, 0, head_h + 1))
            .rect(0.8, shaft_id + 1).extrude(stem_l))
    plug = plug.cut(slit)
    # 구분용 노치 (5.4=1개, 6.0=2개, 6.5=3개)
    n = SHAFT_IDS.index(shaft_id) + 1 if shaft_id in SHAFT_IDS else 0
    for k in range(n):
        notch = (cq.Workplane("XY").center(5, 0).circle(0.7).extrude(head_h)
                 .rotate((0, 0, 0), (0, 0, 1), k * 30))
        plug = plug.cut(notch)
    return plug


# =====================================================================
# 6) 회전 인디케이터 (벨 윗면에 양면테이프)
# =====================================================================
def make_indicator():
    disk = cq.Workplane("XY").circle((MOTOR_D - 1) / 2).extrude(2)
    pointer = (cq.Workplane("XY")
               .polyline([(-3, 0), (3, 0), (0.8, 32), (-0.8, 32)]).close().extrude(2))
    ind = disk.union(pointer).cut(cq.Workplane("XY").circle(5).extrude(2))
    for a in range(0, 360, 30):
        tick = (cq.Workplane("XY", origin=(0, MOTOR_D / 2 - 3.5, 1.4))
                .rect(0.8, 4).extrude(1).rotate((0, 0, 0), (0, 0, 1), a))
        ind = ind.cut(tick)
    return ind


# =====================================================================
# 빌드 & 내보내기
# =====================================================================
parts = {
    "base": make_base(),
    "motor_plate": make_motor_plate(),
    "sensor_carrier": make_sensor_carrier(),
    "spacers": make_spacers(),
    "indicator": make_indicator(),
}
for sid in SHAFT_IDS:
    parts[f"magnet_plug_{sid:.1f}"] = make_magnet_plug(sid)

# 조립 상태
z_plate = BASE_T + TOWER_H
z_carrier = BASE_T + POST_H
asm = cq.Assembly(name="foc_test_stand")
asm.add(parts["base"], name="base", color=cq.Color("gray80"))
asm.add(parts["motor_plate"], name="motor_plate",
        loc=cq.Location((0, 0, z_plate)), color=cq.Color("steelblue"))
asm.add(parts["sensor_carrier"], name="sensor_carrier",
        loc=cq.Location((0, 0, z_carrier)), color=cq.Color("orange"))
asm.add(cq.Workplane("XY").rect(SENSOR_W, SENSOR_L).extrude(1.6), name="as5600_dummy",
        loc=cq.Location((0, 0, z_carrier + CARRIER_T - SENSOR_POCKET)), color=cq.Color("lightblue"))
asm.add(cq.Workplane("XY").circle(MOTOR_D / 2).extrude(19.5), name="motor_dummy",
        loc=cq.Location((0, 0, z_plate + PLATE_T)), color=cq.Color("gray30"))
asm.add(parts["indicator"], name="indicator",
        loc=cq.Location((0, 0, z_plate + PLATE_T + 19.5)), color=cq.Color("gold"))
asm.add(cq.Workplane("XY").rect(ESC_L, ESC_W).extrude(1.6), name="esc1_dummy",
        loc=cq.Location((TRAY_X, 0, BASE_T + 2)), color=cq.Color("purple"))

if __name__ == "__main__":
    out = Path(__file__).parent / "out"
    out.mkdir(exist_ok=True)
    for name, wp in parts.items():
        cq.exporters.export(wp, str(out / f"{name}.step"))
        cq.exporters.export(wp, str(out / f"{name}.stl"), tolerance=0.02, angularTolerance=0.1)
    asm.export(str(out / "assembly.step"))

    chip_top = z_carrier + CARRIER_T - SENSOR_POCKET + 1.6 + 0.9
    print(f"모터판 윗면 높이: {z_plate + PLATE_T:.1f} mm")
    print(f"AS5600 칩 윗면(스페이서 없음): {chip_top:.1f} mm "
          f"-> 모터 바닥면 아래 {z_plate + PLATE_T - chip_top:.1f} mm")
    print(f"베이스 크기: {BASE_X1 - BASE_X0:.0f} x {2 * BASE_Y:.0f} mm")

    try:   # VS Code + OCP CAD Viewer 에서 실행 시 표시
        from ocp_vscode import show
        show(asm)
    except Exception:
        pass
